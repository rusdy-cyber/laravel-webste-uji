<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     * 
     * @return void
     * 
     */
    public function up()
    {
        Schema::create('buku', function (Blueprint $table) {
            $table->string('gambar');
            $table->id();
            $table->string('judul_buku');
            $table->string('kode_buku')->unique();
            $table->string('penerbit');
            $table->string('kategori');
            $table->longText('deskripsi');
            $table->date('tahun_terbit')->nullable();
            $table->timestamps();
            $table->string('penulis');
        });
    }
    /**
     *	Reverse the migrations.
     *
     *	@return void
     */
    public function down()
    {
        Schema::dropIfExists('buku');
    }
};