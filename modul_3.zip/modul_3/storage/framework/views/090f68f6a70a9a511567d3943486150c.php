<!DOCTYPE html>
<html lang="en">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Homepage</title>
</head>

<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/">Politeknik Negeri Bengkalis | D-IV Keamanan Sistem Informasi</a>
        </div>
    </nav>
    <div class="container">
        <div class="row mt-3">
            <div class="col">
                <h4 class="text-secondary">Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
            </div>
            <div class="col"></div>
            <div class="col-1">
                <a href="<?php echo e(route('logout')); ?>" style="text-decoration: none">
                    <p class="text-end text-black fw-semibold">Logout</p>
                </a>
            </div>
        </div>
    </div>

    <div class="row mt-5 mb-5">
        <div class="col"></div>
        <div class="col-6">
            <form action="" method="GET">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <input type="search" name="search" class="form-control rounded" placeholder="Cari nama buku"
                        aria-label="Search" aria-describedby="search-addon" />
                    <button type="submit" class="btn btn-outline-primary">Search</button>
                </div>
            </form>
        </div>
        <div class="col"></div>
    </div>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-2"><img style="width: 150px" src="<?php echo e(asset('images/' . $buku->gambar)); ?>"
                            alt="cover buku"></div>
                    <div class="col-2">
                        <p class="fw-bold">Judul</p>
                        <p class="fw-bold">Penulis</p>
                        <p class="fw-bold">Penerbit</p>
                        <p class="fw-bold">Tahun Terbit</p>
                        <p class="fw-bold">Deskripsi Buku</p>
                    </div>
                    <div class="col-8">
                        <p><?php echo e($buku->judul_buku); ?></p>
                        <p><?php echo e($buku->penulis); ?></p>
                        <p><?php echo e($buku->penerbit); ?></p>
                        <p><?php echo e($buku->tahun_terbit); ?></p>
                        <p><?php echo e($buku->deskripsi); ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($data->links()); ?>

    </div>

    <script>
        src = "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\modul_3\resources\views/user/home.blade.php ENDPATH**/ ?>